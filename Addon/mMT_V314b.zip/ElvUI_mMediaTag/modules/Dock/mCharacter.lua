local E, L = unpack(ElvUI)
local DT = E:GetModule("DataTexts")

--Lua functions
local pairs = pairs
local format = format
local wipe = wipe
local select = select
local pi = math.pi

--WoW API / Variables
local _G = _G
local GetInventoryItemDurability = GetInventoryItemDurability
local GetInventoryItemTexture = GetInventoryItemTexture
local GetInventoryItemLink = GetInventoryItemLink
local GetMoneyString = GetMoneyString

--Variables
local mText = format("Dock %s", CHARACTER_BUTTON)
local mTextName = "mCharacter"
local REPAIR_COST = REPAIR_COST
local tooltipString = "%d%%"
local totalDurability = 0
local invDurability = {}
local totalRepairCost

local slots = {
	[1] = _G.INVTYPE_HEAD,
	[3] = _G.INVTYPE_SHOULDER,
	[5] = _G.INVTYPE_CHEST,
	[6] = _G.INVTYPE_WAIST,
	[7] = _G.INVTYPE_LEGS,
	[8] = _G.INVTYPE_FEET,
	[9] = _G.INVTYPE_WRIST,
	[10] = _G.INVTYPE_HAND,
	[16] = _G.INVTYPE_WEAPONMAINHAND,
	[17] = _G.INVTYPE_WEAPONOFFHAND,
	[18] = _G.INVTYPE_RANGED,
}

local function colorize(num)
	if num >= 0 then
		return 0.1, 1, 0.1
	else
		return E:ColorGradient(-(pi / num), 1, 0.1, 0.1, 1, 1, 0.1, 0.1, 1, 0.1)
	end
end

local function mCheckDurability()
	if totalDurability <= 35 then
		local r, g, b = E:ColorGradient(totalDurability * 0.01, 1, 0.1, 0.1, 1, 1, 0.1, 0.1, 1, 0.1)
		return r, g, b, 1
	end
end

local function mDockCheckFrame()
	return (CharacterFrame and CharacterFrame:IsShown())
end

function mMT:CheckFrameCharacter(self)
	self.mIcon.isClicked = mDockCheckFrame()
	mMT:DockTimer(self)
	if mCheckDurability() then
		mMT:DockCustomColor(self, mCheckDurability())
	end
end

local function OnEnter(self)
	local nhc, hc, myth, mythp, other, titel, tip = mMT:mColorDatatext()
	self.mIcon.isClicked = mDockCheckFrame()
	mMT:mOnEnter(self, "CheckFrameCharacter")

	if E.db.mMT.dockdatatext.tip.enable then
		DT.tooltip:ClearLines()
		if E.Retail then
			local avg, avgEquipped, avgPvp = GetAverageItemLevel()
			DT.tooltip:AddDoubleLine(STAT_AVERAGE_ITEM_LEVEL, format("%0.2f", avg), 1, 1, 1, 0.1, 1, 0.1)
			DT.tooltip:AddDoubleLine(
				GMSURVEYRATING3,
				format("%0.2f", avgEquipped),
				1,
				1,
				1,
				colorize(avgEquipped - avg)
			)
			DT.tooltip:AddDoubleLine(
				LFG_LIST_ITEM_LEVEL_INSTR_PVP_SHORT,
				format("%0.2f", avgPvp),
				1,
				1,
				1,
				colorize(avgPvp - avg)
			)
			DT.tooltip:AddLine(" ")
		end

		DT.tooltip:AddLine(format("%s%s|r", titel, L["Durability"]))
		for slot, durability in pairs(invDurability) do
			DT.tooltip:AddDoubleLine(
				format(
					"|T%s:14:14:0:0:64:64:4:60:4:60|t %s",
					GetInventoryItemTexture("player", slot),
					GetInventoryItemLink("player", slot)
				),
				format(tooltipString, durability),
				1,
				1,
				1,
				E:ColorGradient(durability * 0.01, 1, 0.1, 0.1, 1, 1, 0.1, 0.1, 1, 0.1)
			)
		end

		if totalRepairCost > 0 then
			DT.tooltip:AddLine(" ")
			DT.tooltip:AddDoubleLine(REPAIR_COST, GetMoneyString(totalRepairCost), 0.6, 0.8, 1, 1, 1, 1)
		end

		DT.tooltip:Show()
	end
end

local function OnEvent(self, event, ...)
	self.mSettings = {
		Name = mTextName,
		text = {
			onlytext = false,
			special = true,
			textA = E.db.mMT.dockdatatext.character.option ~= "none",
			textB = false,
		},
		icon = {
			texture = mMT.Media.DockIcons[E.db.mMT.dockdatatext.character.icon],
			color = E.db.mMT.dockdatatext.character.iconcolor,
			customcolor = E.db.mMT.dockdatatext.character.customcolor,
		},
	}

	local r, g, b = 1, 1, 1
	local color = nil
	local text = nil

		totalDurability = 100
		totalRepairCost = 0

		wipe(invDurability)

		for index in pairs(slots) do
			local currentDura, maxDura = GetInventoryItemDurability(index)
			if currentDura and maxDura > 0 then
				local perc, repairCost = (currentDura / maxDura) * 100, 0
				invDurability[index] = perc

				if perc < totalDurability then
					totalDurability = perc
				end

				if E.Retail and E.ScanTooltip.GetTooltipData then
					E.ScanTooltip:SetInventoryItem("player", index)
					E.ScanTooltip:Show()

					local data = E.ScanTooltip:GetTooltipData()
					repairCost = data and data.repairCost
				else
					repairCost = select(3, E.ScanTooltip:SetInventoryItem("player", index))
				end

				totalRepairCost = totalRepairCost + (repairCost or 0)
			end
		end

		if E.db.mMT.dockdatatext.character.color and E.db.mMT.dockdatatext.character.option == "durability" then
			r, g, b = E:ColorGradient(totalDurability * .01, 1, .1, .1, 1, 1, .1, .1, 1, .1)
			color = E:RGBToHex(r, g, b)
		end

		if E.db.mMT.dockdatatext.character.option == "durability" then
			text = format("%d%%|r", totalDurability)
		elseif E.db.mMT.dockdatatext.character.option == "ilvl" then
		local avg, avgEquipped = GetAverageItemLevel()
		if E.db.mMT.dockdatatext.character.color and E.db.mMT.dockdatatext.character.option == "ilvl" then
			r, g, b = GetItemLevelColor()
			color = E:RGBToHex(r, g, b)
		end
		text = mMT:round(avgEquipped or 0)
	end

	mMT:DockInitialization(self, event, text, nil, color)

	if mCheckDurability() then
		E:Flash(self, 0.5, true)
		mMT:DockCustomColor(self, mCheckDurability())
	else
		E:StopFlash(self)
		mMT:DockNormalColor(self)
	end
end

local function OnLeave(self)
	if E.db.mMT.dockdatatext.tip.enable then
		DT.tooltip:Hide()
	end

	self.mIcon.isClicked = mDockCheckFrame()
	mMT:mOnLeave(self)

	if mCheckDurability() then
		mMT:DockCustomColor(self, mCheckDurability())
	end
end

local function OnClick(self)
	if mMT:CheckCombatLockdown() then
		mMT:mOnClick(self, "CheckFrameCharacter")
		if mCheckDurability() then
			mMT:DockCustomColor(self, mCheckDurability())
		end
		_G.ToggleCharacter("PaperDollFrame")
	end
end

DT:RegisterDatatext(
	mTextName,
	"mDock",
	{ "UPDATE_INVENTORY_DURABILITY", "PLAYER_AVG_ITEM_LEVEL_UPDATE" },
	OnEvent,
	nil,
	OnClick,
	OnEnter,
	OnLeave,
	mText,
	nil,
	nil
)
